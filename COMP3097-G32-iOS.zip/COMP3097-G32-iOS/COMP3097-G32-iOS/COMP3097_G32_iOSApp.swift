//
//  COMP3097_G32_iOSApp.swift
//  COMP3097-G32-iOS
//
//  Created by Vu.Quan.Tran on 2026-02-12.
//

import SwiftUI

@main
struct COMP3097_G32_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
